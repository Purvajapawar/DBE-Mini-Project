<?php
session_start();
if (!isset($_SESSION['user'])) { header('Location: login.php'); exit; }
require 'config.php';

$id = $_GET['id'];
$student = $pdo->query("SELECT * FROM students WHERE id=$id")->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare('UPDATE students SET name=?, email=?, course=? WHERE id=?');
    $stmt->execute([$_POST['name'], $_POST['email'], $_POST['course'], $id]);
    header('Location: index.php');
}
?>
<!DOCTYPE html>
<html>
<head><title>Edit Student</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container">
<h2>Edit Student</h2>
<form method="post">
<input type="text" name="name" value="<?= $student['name'] ?>" required>
<input type="email" name="email" value="<?= $student['email'] ?>" required>
<input type="text" name="course" value="<?= $student['course'] ?>" required>
<button type="submit">Update</button>
</form>
<a href="index.php" class="btn">Back</a>
</div>
</body></html>
