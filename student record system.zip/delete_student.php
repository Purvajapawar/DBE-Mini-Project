<?php
session_start();
if (!isset($_SESSION['user'])) { header('Location: login.php'); exit; }
require 'config.php';
$id = $_GET['id'];
$pdo->prepare('DELETE FROM students WHERE id=?')->execute([$id]);
header('Location: index.php');
?>
