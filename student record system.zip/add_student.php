<?php
session_start();
if (!isset($_SESSION['user'])) { header('Location: login.php'); exit; }
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare('INSERT INTO students (name, email, course) VALUES (?, ?, ?)');
    $stmt->execute([$_POST['name'], $_POST['email'], $_POST['course']]);
    header('Location: index.php');
}
?>
<!DOCTYPE html>
<html>
<head><title>Add Student</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container">
<h2>Add Student</h2>
<form method="post">
<input type="text" name="name" placeholder="Full Name" required>
<input type="email" name="email" placeholder="Email" required>
<input type="text" name="course" placeholder="Course" required>
<button type="submit">Add</button>
</form>
<a href="index.php" class="btn">Back</a>
</div>
</body></html>
