<?php
session_start();
if (!isset($_SESSION['user'])) { header('Location: login.php'); exit; }
require 'config.php';
$students = $pdo->query('SELECT * FROM students')->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head><title>Dashboard</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container">
<h2>Student Records</h2>
<a href="add_student.php" class="btn">Add Student</a>
<a href="logout.php" class="logout">Logout</a>
<table>
<tr><th>ID</th><th>Name</th><th>Email</th><th>Course</th><th>Actions</th></tr>
<?php foreach ($students as $s): ?>
<tr>
<td><?= $s['id'] ?></td>
<td><?= $s['name'] ?></td>
<td><?= $s['email'] ?></td>
<td><?= $s['course'] ?></td>
<td>
<a href="edit_student.php?id=<?= $s['id'] ?>">Edit</a> |
<a href="delete_student.php?id=<?= $s['id'] ?>" onclick="return confirm('Delete?')">Delete</a>
</td>
</tr>
<?php endforeach; ?>
</table>
</div>
</body></html>
